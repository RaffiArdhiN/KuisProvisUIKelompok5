package com.example.flutter_application_quizui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
